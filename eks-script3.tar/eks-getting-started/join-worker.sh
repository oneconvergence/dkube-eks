#!/bin/bash
#echo "JOINING THE NODES ..."
#sleep 10
terraform output -json kubeconfig | jq -r . > ~/.kube/config
terraform output -json config_map_aws_auth | jq -r . > config_map_aws_auth.yaml
kubectl apply -f config_map_aws_auth.yaml
#echo "NODES JOINED SUCCESSFULLY :-)"
